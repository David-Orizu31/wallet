
	<!-- favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.fastway.com.au/favicon-16x16.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.fastway.com.au/Fastway-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.fastway.com.au/Fastway-icon-144x144.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="navbar navbar-inverse" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed navbar-collapse-main" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
              <i class="fa fa-bars"></i>
            </button>
            <a href="index.php">
              			<img class="logo-img-sm" src="./index_files/fastwaycouriers.png" alt="Fastway Couriers">
            </a>
        </div>







        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <a class="dropdown-toggle" href="tracking.php" data-toggle="dropdown">Services <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="register.php">Send your parcel</a></li>
                                    <li><a class="parent" href="register.php">Registration</a></li>
                                    <li><a class="parent" href="tracking.php">National satchels</a></li>
                             </ul>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/tools/" data-toggle="dropdown">Tools <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="tracking.php">Track</a></li>
                                    <li><a class="parent" href="tracking.php">Courier locator</a></li>
                                    <li><a class="parent" href="tracking.php">Quick quote</a></li>
                                    <li><a class="parent" href="tracking.php">Our rates</a></li>
                                    <li><a class="parent" href="tracking.php">Fast label</a></li>
                                    <li><a class="parent" href="tracking.php">Customer portal</a></li>
                                </ul>
                        </li>
                      <!--  <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/franchising/" data-toggle="dropdown">Franchising <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="https://www.fastway.com.au/franchising/courier-franchise/">Courier franchise</a></li>
                                    <li><a class="parent" href="https://www.fastway.com.au/franchising/regional-franchise/">Regional franchise</a></li>
                            </ul>
                        </li>-->
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/why-fastway/" data-toggle="dropdown">Why Fastway <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="About.php">About us</a></li>
                                    <li><a class="parent" href="customers.php">Our customers</a></li>
                                    <li><a class="parent" href="About.php">Our awards</a></li>
                                    <li><a class="parent" href="customers.php">Our community</a></li>
                            </ul>
                        </li>
                    <li>
                        <a href="tracking.php">Courier locator</a>

                    </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="contact.php" data-toggle="dropdown">Contact us <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="faq.php">FAQs</a></li>
                                    <li><a class="parent" href="contact.php">Fastway depot</a></li>
                                    <li><a class="parent" href="tracking.php">Fastway courier</a></li>
                                    <li><a class="parent" href="feedback.php">Feedback</a></li>
                            </ul>
                        </li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>
<!DOCTYPE html>
<html lang="en" ng-app="" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="keywords" content="">


	<title>Fastway Global Logistics Plc | Home</title>

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="./index_files/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./index_files/fastway.css">
	<link rel="stylesheet" type="text/css" href="./index_files/font-awesome.css">

	<!-- favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.fastway.com.au/favicon-16x16.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.fastway.com.au/Fastway-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.fastway.com.au/Fastway-icon-144x144.png">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Javascripts -->
    <script type="text/javascript" async="" src="./index_files/js"></script>
    <script src="./index_files/143510159313672" async=""></script>
    <script async="" src="./index_files/fbevents.js.download"></script>
    <script type="text/javascript" async="" src="./index_files/insight.min.js.download"></script>
    <script type="text/javascript" async="" src="./index_files/f.txt"></script>
    <script async="" src="./index_files/analytics.js.download"></script>
    <script async="" src="./index_files/gtm.js.download"></script>
    <script src="./index_files/jquery.min.js.download"></script>
    <script src="./index_files/bootstrap.min.js.download"></script>
	<script src="./index_files/jquery.validate.min.js.download"></script>
	<!-- <script src="https://ajax.aspnetcdn.com/ajax/mvc/5.1/jquery.validate.unobtrusive.min.js"></script> -->

<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',4000,
{'GTM-K2DF7P7':true});</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PF4VXP');</script>
<!-- End Google Tag Manager -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3860999-2', 'auto');
  ga('require', 'GTM-K2DF7P7');
  ga('send', 'pageview');

</script>


	<script src="./index_files/f(1).txt"></script></head>



 <body>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PF4VXP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->










<script>
$(document).ready(function() {
     if($(window).width()>769){
        $('.dropdown').hover(function() {

			 $(this).children('.dropdown-menu').slideDown(200);

        }, function() {
             $(this).children('.dropdown-menu').slideUp(200);

        });

        $('.dropdown > a').click(function(){
            location.href = this.href;
        });

	 }
});
</script>








				<section class="visible-xs">
				<a href="contact.php"><img src="./index_files/1y4a3655_pearl_tarik_arzan_matt_laura_vans.jpg" alt=""> </a>
			</section>





<divclass="banner-wrapper">

	<div class="bannerImage" style="background-image: url(https://www.fastway.com.au/media/1424/homepagebannerdeliveringgoods.jpg)">


<script src="./index_files/jquery.min.js(1).download" type="text/javascript"></script>
<script src="./index_files/jquery-ui-1.8.16.autocomplete.min.js.download" type="text/javascript"></script>
<link rel="stylesheet" href="./index_files/jquery-ui.css" type="text/css">



<script type="text/javascript">//jQuery.noConflict();
	jQuery(function() {
		jQuery("#qq-button").click(function() {
			var from = jQuery("#SendingFrom").val();
			var to = jQuery("#SendingTo").val();
			var weight = jQuery("#Weight").val();
			var postcode = jQuery("#Postcode").val();
			var length = jQuery("#Length").val();
			var width = jQuery("#Width").val();
			var height = jQuery("#Height").val();
			if (length > 210 || width > 210 || height > 210) {
				alert("Fastway Australia only allows items 2.1m in length maximum.");
				return;
			}
		document.location.href = "/tools/quick-quote/quick-quote-result?PickupRF=" + from + "&DeliverySuburb=" + to + "&Weight=" + weight + "&Postcode=" + postcode + "&Length=" + length + "&Width=" + width + "&Height=" + height;
		});
		jQuery("#SendingTo").autocomplete({
			"source": function(req, res) {
				var sf = jQuery("#SendingFrom").val();
				var term = jQuery("#SendingTo").val();
				jQuery.getJSON("/address-locator-api/?callback=?", {
					"RFCode": sf,
					"term": term
				}, function(data) {
					res(data.result);
				});
			},
			"minLength": 3,
			"select": function(evt, ui) {
				jQuery("#SendingTo").val(ui.item.Town);
				jQuery("#Postcode").val(ui.item.Postcode);
				return false;
			}
		});
		jQuery("#Postcode").autocomplete({
			"source": function(req, res) {
				var sf = jQuery("#SendingFrom").val();
				var term = jQuery("#Postcode").val();
				jQuery.getJSON("/address-locator-api/?callback=?", {
					"RFCode": sf,
					"term": term
				}, function(data) {
					if (data.result) {
						for (var item in data.result) {
							var me = data.result[item];
							me.label = me.Postcode + "," + me.State + "," + me.Town;
						}
					}
					res(data.result);
				});
			},
			"minLength": 3,
			"select": function(evt, ui) {
				jQuery("#SendingTo").val(ui.item.Town);
				jQuery("#Postcode").val(ui.item.Postcode);
				return false;
			}
		});
	});</script>











<!-- Nav Tab --------------------------------------------------------------------------------------------------->

<div class="tabtools-wrapper bannerImage">


<div class="hometabpanelwrapper">
<div class="container">
<div class="row">

<div class="col-xs-12 col-sm-3">


<div class="hometabpanel panel with-nav-tabs panel-default">



<ul class="nav nav-tabs">
<li class="active"><a href="tracking.php" data-toggle="tab">
<h4>Track</h4>
</a></li>
<li><a href="tracking.php" data-toggle="tab">
<h4>Quote</h4>
</a></li>
<li><a href="contact.php">
<h4>Contact</h4>
</a></li>
</ul>



 <!-- Tab content ------------------------------------------------------->

<div class="panel-body">
<div class="tab-content">



<!-- Track ------------------------------------------------------->


<div id="tabtrack" class="tab-pane fade in active">
<h4>Track your parcel's journey</h4>
<div id="form_tool">
    <form action="tracking_process.php" method="post">
<div class="form-group">
    <input id="main_label_no2" class="form-control input-lg" name="trackingnumbb" maxlength="13" placeholder="Enter Tracking number" style="background-color: #f5f5f5;" type="text">
</div>
<input type="submit" id="main_trace2" class="btn btn-red btn-lg" name="submit2" value="TRACK">
    </form></div>
<p><span class="txtsmall"></span></p>
</div>



 <!-- Quote  ------------------------------------------------------->

<div class="tab-pane fade" id="tabquote">
<h4>Quick quote for account holders</h4>
<div class="qqWrapper">

<form class="qqHomeTab">

<!-- Send from -->
<select style="margin-bottom:8px; border-radius: 0px;" name="pFranchisee" class="qqInput qqSelectLocation form-control" id="SendingFrom">
<option selected="selected">Select location</option><option value="ADL">Adelaide</option><option value="ALB">Albury</option><option value="BEN">Bendigo</option><option value="BRI">Brisbane</option><option value="CNS">Cairns</option><option value="CBR">Canberra</option><option value="CAP">Capricorn Coast</option><option value="CCT">Central Coast</option><option value="CFS">Coffs Harbour</option><option value="GEE">Geelong</option><option value="GLD">Gold Coast</option><option value="TAS">Hobart</option><option value="LAU">Launceston</option><option value="MKY">Mackay</option><option value="MEL">Melbourne</option><option value="NEW">Newcastle</option><option value="NTH">Northern Rivers</option><option value="OAG">Orange</option><option value="PER">Perth</option><option value="PQQ">Port Macquarie</option><option value="SUN">Sunshine Coast</option><option value="SYD">Sydney</option><option value="TMW">Tamworth</option><option value="TOO">Toowoomba</option><option value="TVL">Townsville</option><option value="BDB">Wide Bay</option><option value="WOL">Wollongong</option></select>

<span class="ui-helper-hidden-accessible" aria-live="polite" role="status"></span>


 <!-- Send to -->
<input type="text" autocomplete="off" id="SendingTo" name="vTown" class="qqInput qqSendTo ui-autocomplete-input form-control" placeholder="Sending to" style="margin-bottom:8px; border-radius: 0px; z-index:244" role="textbox" aria-autocomplete="list" aria-haspopup="true">

  <span class="ui-helper-hidden-accessible" aria-live="polite" role="status"></span>

	 <!-- Postcode -->
  <input type="hidden" autocomplete="off" id="Postcode" class="qqPostcode ui-autocomplete-input" name="vPostcode" maxlength="4" placeholder="Postcode" role="textbox" aria-autocomplete="list" aria-haspopup="true">


	 <!-- Weight -->
<input type="text" maxlength="3" placeholder="Weight (kg)" id="Weight" class="qqInput qqWeight form-control" name="vWeight" style="margin-bottom:8px; border-radius: 0px;">






	 <!-- Length -->
<input type="text" style="width:30%; border-radius:0px; margin-right:5%; float:left; margin-bottom:12px;" maxlength="3" placeholder="L (cm)" id="Length" class="qqInput qqInputSize qqLength form-control" name="vLength">

<!-- Width -->
	<input type="text" style="width:30%; border-radius:0px; margin-right:5%; float:left; margin-bottom:12px;" maxlength="3" placeholder="W (cm)" id="Width" class="qqInput qqInputSize qqWidth form-control" name="vWidth">

	<!-- Height -->
	<input type="text" style="width:30%; border-radius:0px; float:left; margin-bottom:12px;" maxlength="3" placeholder="H (cm)" id="Height" class="qqInput qqInputSize qqHeight form-control" name="vHeight">




<a>Get quote</a>
</form></div>
</div>





<!-- Contact  ------------------------------------------------------->

<div class="tab-pane fade" id="tabcontactUs">
<h4>Contact a Fastway depot</h4>




<div class="dropdown">
  <button class="btn btn-default dropdown-toggle" style="border-radius:0px; width:100%; font-family:arial; text-align:left" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
   Select your nearest location
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1" style="width:100%; position:relative">


		<li><a href="">Adelaide</a></li>
		<li><a href="">Albury</a></li>
		<li><a href="">Bendigo</a></li>
		<li><a href="">Brisbane</a></li>
		<li><a href="">Cairns</a></li>
		<li><a href="">Canberra</a></li>
		<li><a href="">Capricorn Coast</a></li>
		<li><a href="">Central Coast</a></li>
		<li><a href="">Coffs Harbour</a></li>
		<li><a href="">Geelong &amp; Ballarat</a></li>
		<li><a href="">Gold Coast</a></li>
		<li><a href="">Hobart</a></li>
		<li><a href="">Launceston</a></li>
		<li><a href="">Mackay</a></li>
		<li><a href="">Melbourne</a></li>
		<li><a href="">Newcastle</a></li>
		<li><a href="">Northern Rivers</a></li>
		<li><a href="">Orange</a></li>
		<li><a href="">Perth</a></li>
		<li><a href="">Port Macquarie</a></li>
		<li><a href="">Sunshine Coast</a></li>
		<li><a href="">Sydney</a></li>
		<li><a href="">Tamworth</a></li>
		<li><a href="">Toowoomba</a></li>
		<li><a href="">Townsville</a></li>
		<li><a href="">Wide Bay</a></li>
		<li><a href="">Wollongong</a></li>

  </ul>
</div>





</div>



<!-- End Contact ---->



</div><!-- End tab-content body --->
</div><!-- End panel --->
</div>
</div><!-- End col4 tabs --->



	<div class="col-sm-9 hidden-xs">
			<a href="" style="width:100%; height:320px;display:block; position: absolute; left: 0px; top: 0px; z-index: 22; "></a>

</div>




</div><!-- End row --->





















</div><!-- End Container --->


</div><!-- End Wrapper --->

</div>



     </div>







<section class="section-row homeIcons">
<div class="container">



<div class="col-sm-12">
<h3>Your local and national courier experts</h3>
</div>


  <div class="RollbtnWrapper">
    <ul id="RollBtnList">


	  <li>
<div class="iconWrapper borderRight">

<a href="">

    	<img src="./index_files/icon_trolly.png" alt="home_icons_sendpng">


 <h4>Send parcel</h4>
</a>

</div>

</li>


      <li>
 <div class="iconWrapper borderRight">

	 <a href="">

    	<img src="./index_files/icon_ccl.png" alt="home_icons_cclpng">


 <h4>Calling card left</h4>
</a>

</div>
</li>


      <li>
<div class="iconWrapper borderRight">

	<a href="">

    	<img src="./index_files/icon_ebay.png" alt="home_icons_ebaypng">


 <h4>Selling on eBay</h4>
</a>

</div>
</li>


<li>
<div class="iconWrapper borderRight">

	<a href="">

    	<img src="./index_files/icon_franchise.png" alt="home_icons_franchisepng">


 <h4>Franchise</h4>
</a>


</div>
</li>


<li>
<div class="iconWrapper hidden-xs">

	<a href="">

    	<img src="./index_files/toolsicon_location.png" alt="home_icons_maplocationspng">


 <h4>Pick-up locations</h4>
</a>

</div>
</li>




 </ul>

</div>




</div> 	<!-- end Container ----->
</section>	<!-- end button section ----->

	<div class="bg-white paddTopBottomPlus">
		<div class="container">

<div class="col-sm-9">

<h2 style="padding-bottom:22px">Discover a better parcel service with Fastway</h2>
<p> </p>

	<div class="row">

		<div class="col-sm-6 paddBottom">
		<div class="embed-responsive embed-responsive-16by9">
<iframe width="853" height="480" src="./index_files/EswTwDVROPY.html" frameborder="0" allowfullscreen=""></iframe>
</div>
		</div>

		<div class="col-sm-6 pBlue">
		<div class="pBlue">
<h4>At Fastway, our approach to courier services is unique</h4>
<p>Our Courier Franchisees offer a cost effective, reliable, timetable courier service, backed up by the latest computer technology and online parcel track and trace facilities, making Fastway Couriers the ideal choice for small to medium sized businesses.</p>
<p>&nbsp;</p>
<a href="" class="btn btn-red btn-lg">Get started with Fastway</a>
<p>&nbsp;</p>
</div>
<p>&nbsp;</p>
		</div>
	</div>
</div>

			<div class="col-sm-3">
	 <div class="panel-group panel-group-depots" id="accordion">
 <h4>Your local Fastway depot</h4>

  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseACT">
      <h4 class="panel-title"> ACT</h4>
    </div>

    <div id="collapseACT" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Canberra</a>	</li>
		</ul>

      </div>
    </div>
  </div>





  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseNSW">
      <h4 class="panel-title"> NSW </h4>
    </div>

    <div id="collapseNSW" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Albury</a>	</li>
			<li> <a href="">Central Coast</a>	</li>
			<li> <a href="">Coffs Harbour</a>	</li>
			<li> <a href="">Newcastle</a>	</li>
			<li> <a href="">Northern Rivers</a>	</li>
			<li> <a href="">Orange</a>	</li>
			<li> <a href="">Port Macquarie</a>	</li>
			<li> <a href="">Sydney</a>	</li>
			<li> <a href="">Tamworth</a>	</li>
			<li> <a href="">Wollongong</a>	</li>
		</ul>


      </div>
    </div>
  </div>



  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseQLD">
      <h4 class="panel-title"> QLD </h4>
    </div>

    <div id="collapseQLD" class="panel-collapse collapse">
      <div class="panel-body">



		<ul class="depotAccorList">
			<li> <a href="">Brisbane</a>	</li>
			<li> <a href="">Cairns</a>	</li>
			<li> <a href="">Capricorn Coast</a>	</li>
			<li> <a href="">Gold Coast</a>	</li>
			<li> <a href="">Mackay</a>	</li>
			<li> <a href="">Sunshine Coast</a>	</li>
			<li> <a href="">Toowoomba</a>	</li>
			<li> <a href="">Townsville</a>	</li>
			<li> <a href="">Wide Bay</a>	</li>
		</ul>



      </div>
    </div>
  </div>


  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseSA">
      <h4 class="panel-title"> SA </h4>
    </div>

    <div id="collapseSA" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Adelaide</a>	</li>
		</ul>

      </div>
    </div>
  </div>


  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTAS">
      <h4 class="panel-title"> TAS </h4>
    </div>

    <div id="collapseTAS" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Hobart</a>	</li>
			<li> <a href="">Launceston</a>	</li>
		</ul>

      </div>
    </div>
  </div>


  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseVIC">
      <h4 class="panel-title"> VIC </h4>
    </div>

    <div id="collapseVIC" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Bendigo</a>	</li>
			<li> <a href="">Geelong &amp; Ballarat</a>	</li>
			<li> <a href="">Melbourne</a>	</li>
		</ul>

      </div>
    </div>
  </div>


  <div class="panel panel-default">
    <div class="panel-heading collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseWA">
      <h4 class="panel-title"> WA </h4>
    </div>

    <div id="collapseWA" class="panel-collapse collapse">
      <div class="panel-body">


		<ul class="depotAccorList">
			<li> <a href="">Perth</a>	</li>
		</ul>

      </div>
    </div>
  </div>










</div>
			</div>

	</div>
</div>


	<section class="sectionFranchise">
		<div class="container">



<div class="col-sm-6 hidden-xs">
		<div class="row">
      <img src="./index_files/franchiseopportunities2cfs.jpg">

	</div>
</div>




<div class="col-sm-6">
<h1>Franchise opportunities</h1>
<h4 style="margin-top:0px">Join our award winning team and share our success</h4>
<p></p>

<div style="margin-left: 16px; padding-top:12px; padding-bottom: 12px;">
        <ul class="benefitslistWhite">
                <li>Low start-up costs</li>
                <li></li>
                <li>Exclusive territory</li>
                <li></li>
                <li>Multiple award winning franchise system</li>
                <li></li>
                <li>Unparalleled support and training</li>
        </ul>




	</div>



<p><a style="margin-bottom:22px" href="" class="btn btn-red">Franchise opportunities</a></p>
<p> </p>
</div>





	</div>
	</section>


<div class="paddTopBottomPlus bottomLogos">
	<div class="container">
		<h3>You’re in great company</h3>
		<p class="pBlue">We’re proud to be the courier service provider to over 75,000 customers, large and small across the globe.</p>

      	<img src="./index_files/footerlogoscustomers.png">

	</div>
</div>

<!--- 	style="background-image: url(/media/1502/homearamexbanner.jpg)"


      <img src="/media/1502/homearamexbanner.jpg"/>



	--->

<div class="AramexBgrdImage" style="background-image: url(https://www.fastway.com.au/media/1502/homearamexbanner.jpg)">
		<div class="container">



<div class="col-sm-6">

<div class="aramexTextBgrd">
<h2>Part of the Aramex global network</h2>
<p>In 2016 Fastway Couriers became part of the of Aramex global network. Known for their innovative approach and leading technologies, Aramex is a prominent global logistics company. As part of the Aramex family, Fastway now has the opportunity to extend its service offerings into the international market, supporting our customers in taking their products to the world.</p>

<a class="btn btn-outline" style="margin-bottom:12px; margin-top:12px" href="" target="_blank">Learn more&nbsp;</a>
</div>

</div>


<div class="col-sm-6">


</div>



	</div>
	</div>










<footer class="footerBtm">
<div class="container">
<section>
<div class="footerWrapper">


<div class="col-xs-12">
<div class="hidden-xs">

	<h4>Fastway depots</h4>


		<ul class="footerDepots">
			<li> <a href="">Adelaide</a>	</li>
			<li> <a href="">Albury</a>	</li>
			<li> <a href="">Bendigo</a>	</li>
			<li> <a href="">Brisbane</a>	</li>
			<li> <a href="">Cairns</a>	</li>
			<li> <a href="">Canberra</a>	</li>
			<li> <a href="">Capricorn Coast</a>	</li>
			<li> <a href="">Central Coast</a>	</li>
			<li> <a href="">Coffs Harbour</a>	</li>
			<li> <a href="">Geelong &amp; Ballarat</a>	</li>
			<li> <a href="">Gold Coast</a>	</li>
			<li> <a href="">Hobart</a>	</li>
			<li> <a href="">Launceston</a>	</li>
			<li> <a href="">Mackay</a>	</li>
			<li> <a href="">Melbourne</a>	</li>
			<li> <a href="">Newcastle</a>	</li>
			<li> <a href="">Northern Rivers</a>	</li>
			<li> <a href="">Orange</a>	</li>
			<li> <a href="">Perth</a>	</li>
			<li> <a href="">Port Macquarie</a>	</li>
			<li> <a href="">Sunshine Coast</a>	</li>
			<li> <a href="">Sydney</a>	</li>
			<li> <a href="">Tamworth</a>	</li>
			<li> <a href="">Toowoomba</a>	</li>
			<li> <a href="">Townsville</a>	</li>
			<li> <a href="">Wide Bay</a>	</li>
			<li> <a href="">Wollongong</a>	</li>
		</ul>
<hr>

	</div>
</div>


<div class="col-xs-12 col-md-3">

<div class="hidden-xs">
	<h4>Why Fastway</h4>
<ul>
  <li><a href="About.php">About us</a></li>
       <!-- <li><a href="/why-fastway/our-blog/">Our blog</a></li>-->
        <li><a href="customers.php">Our customers</a></li>
        <li><a href="customers.php">Our awards</a> </li>
        <li><a href="About.php">Our community</a></li>
</ul>
	</div>

	<div class="hidden-xs">
	<h4><a href="contact.php">Contact us</a></h4>
</div>


  </div>



        <div class="col-xs-12 col-md-3">

<div class="hidden-xs">
<h4>Our services</h4>
<ul>

        <li><a class="CurrentPage" href="register.php">Send your parcel</a></li>
        <li><a href="register.php">Registration</a></li>
		<li><a href="tracking.php">Receiver pays</a></li>
</ul>
</div>


</div>







  <div class="col-xs-12 col-md-3">

<div class="hidden-xs">
	<h4>Franchise</h4>
<ul>
	<li><a href="">Fastway franchise</a></li>
	<li><a href="">Courier franchise opportuniites</a></li>
	<li><a href="">Regional franchise opportunities</a></li>
</ul></div>



<h4>Apps</h4>
<ul>
<li><i class="fa fa-apple"></i><a target="_blank" href=""> Fastway App </a></li>
<li><i class="fa fa-android"></i><a target="_blank" href=""> Fastway App </a></li>
</ul>

  </div>





  <div class="col-xs-12 col-md-3">


	<h4>Terms and conditions</h4>
<ul>
	<li><a href="">Privacy policy</a></li>
	<li><a href="">Privacy collection statement</a></li>
	<li><a href="">Terms of use</a></li>
	<li><a href="">Conditions of carriage</a></li>
	<li><a href="">Authority to leave</a></li>
</ul>


<div class="hidden-xs">
	<h4>Proudly supporting</h4>
<ul>
	<li><a target="_blank" href="https://www.beyondblue.org.au/">Beyond Blue</a></li>
	<li><a target="_blank" href="http://www.daffodilday.com.au/">Cancer Council</a></li>
</ul></div>

  </div>


  </div>




 </section>
 </div>
</footer>





<!-- BACK TO TOP -->
    <span id="top-link-block">
        <a href="index.php/#top" class="well well-sm" onclick="$(&#39;html,body&#39;).animate({scrollTop:0},&#39;slow&#39;);return false;">
  			<i class="fa fa-chevron-up" aria-hidden="true"></i>
        </a>
    </span>
    <!--// BACK TO TOP -->


		 <footer class="copyrightBtm">
      <div class="container">



	<div class="col-xs-7 col-sm-9">
		<p>© Fastway Global Couriers (Worldwide)</p>
	</div>

	<div class="col-xs-5 col-sm-3">
	<div class="social-media" style="float: right;">
		<a target="_blank" href="" style="padding-left: 4px; ; padding-right: 4px;" onclick="ga(&#39;send&#39;, &#39;event&#39;, &#39;Footer&#39;, &#39;clicked&#39;, &#39;Button icon Facebook&#39;); goToPage()"><img alt="icon facebook" src="./index_files/icon_facebook.png"></a>
	</div>
	</div>




 </div>
</footer>


<!-- CDF: No JS dependencies were declared //-->


</divclass="banner-wrapper"><ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" role="listbox" aria-activedescendant="ui-active-menuitem" style="z-index: 29; top: 0px; left: 0px; display: none;"></ul><ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" role="listbox" aria-activedescendant="ui-active-menuitem" style="z-index: 29; top: 0px; left: 0px; display: none;"></ul>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","143510159313672");fbq("set","agent","tmgoogletagmanager","143510159313672");fbq("track","PageView");</script><script src="./index_files/saved_resource" type="text/javascript"></script>

<script type="text/javascript" src="embed.js"></script>

<script src="cookie/load.js"></script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d4a9ded7d27204601c9b951/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>
