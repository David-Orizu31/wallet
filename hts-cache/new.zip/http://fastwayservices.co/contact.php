<!DOCTYPE html>
<!-- saved from url=(0054)https://www.fastway.com.au/contact-us/service-updates/ -->
<html lang="en" ng-app="" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Fastway Couriers currently operates across key metropolitan and regional locations across Australia, offering a low cost and fast courier delivery service. Franchise opportunities also available.">
	<meta name="keywords" content="fastway, couriers, fastway couriers, courier, fastways, fastaway, freight, delivery, pickup, cheap, low cost, cost, economical, franchising, franchise opportunities, franchises, franchisee, business for sale, reliable, pick up, pick-up, van, australia, nsw, vic, wa, sa, qld, act,tas, adelaide, albury, bendigo, brisbane, cairns, canberra, capricorn coast, central coast, coffs harbour, geelong, gold coast, hobart, launceston, mackay, melbourne, newcastle, northern rivers, perth, port macquarie, sunshine coast, sydney, toowoomba, townsville, wide bay, wollongong, tamworth, orange">


	<title>Fastway Couriers | Service updates</title>

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="./contact_files/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./contact_files/fastway.css">
	<link rel="stylesheet" type="text/css" href="./contact_files/font-awesome.css">

	<!-- favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.fastway.com.au/favicon-16x16.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.fastway.com.au/Fastway-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.fastway.com.au/Fastway-icon-144x144.png">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Javascripts -->
    <script type="text/javascript" async="" src="./contact_files/js"></script><script src="./contact_files/143510159313672" async=""></script><script async="" src="./contact_files/fbevents.js.download"></script><script type="text/javascript" async="" src="./contact_files/insight.min.js.download"></script><script type="text/javascript" async="" src="./contact_files/f.txt"></script><script async="" src="./contact_files/analytics.js.download"></script><script async="" src="./contact_files/gtm.js.download"></script><script src="./contact_files/jquery.min.js.download"></script>
    <script src="./contact_files/bootstrap.min.js.download"></script>
	<script src="./contact_files/jquery.validate.min.js.download"></script>
	<!-- <script src="https://ajax.aspnetcdn.com/ajax/mvc/5.1/jquery.validate.unobtrusive.min.js"></script> -->

<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',4000,
{'GTM-K2DF7P7':true});</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PF4VXP');</script>
<!-- End Google Tag Manager -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3860999-2', 'auto');
  ga('require', 'GTM-K2DF7P7');
  ga('send', 'pageview');

</script>

<meta name="ahrefs-site-verification" content="1f401c3df32222850bb6b8258a3f1061f144af831ba0cc5da7ea015e81668810">

	<script src="./contact_files/f(1).txt"></script></head>




 <body>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PF4VXP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->










<script>
$(document).ready(function() {
     if($(window).width()>769){
        $('.dropdown').hover(function() {

			 $(this).children('.dropdown-menu').slideDown(200);

        }, function() {
             $(this).children('.dropdown-menu').slideUp(200);

        });

        $('.dropdown > a').click(function(){
            location.href = this.href;
        });

	 }
});
</script>






	<!-- favicon -->
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.fastway.com.au/favicon-16x16.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.fastway.com.au/Fastway-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.fastway.com.au/Fastway-icon-144x144.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="navbar navbar-inverse" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed navbar-collapse-main" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
              <i class="fa fa-bars"></i>
            </button>
            <a href="index.php">
              			<img class="logo-img-sm" src="./index_files/fastwaycouriers.png" alt="Fastway Couriers">
            </a>
        </div>







        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <a class="dropdown-toggle" href="tracking.php" data-toggle="dropdown">Services <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="register.php">Send your parcel</a></li>
                                    <li><a class="parent" href="register.php">Registration</a></li>
                                    <li><a class="parent" href="tracking.php">National satchels</a></li>
                             </ul>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/tools/" data-toggle="dropdown">Tools <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="tracking.php">Track</a></li>
                                    <li><a class="parent" href="tracking.php">Courier locator</a></li>
                                    <li><a class="parent" href="tracking.php">Quick quote</a></li>
                                    <li><a class="parent" href="tracking.php">Our rates</a></li>
                                    <li><a class="parent" href="tracking.php">Fast label</a></li>
                                    <li><a class="parent" href="tracking.php">Customer portal</a></li>
                                </ul>
                        </li>
                      <!--  <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/franchising/" data-toggle="dropdown">Franchising <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="https://www.fastway.com.au/franchising/courier-franchise/">Courier franchise</a></li>
                                    <li><a class="parent" href="https://www.fastway.com.au/franchising/regional-franchise/">Regional franchise</a></li>
                            </ul>
                        </li>-->
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="https://www.fastway.com.au/why-fastway/" data-toggle="dropdown">Why Fastway <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="About.php">About us</a></li>
                                    <li><a class="parent" href="customers.php">Our customers</a></li>
                                    <li><a class="parent" href="About.php">Our awards</a></li>
                                    <li><a class="parent" href="customers.php">Our community</a></li>
                            </ul>
                        </li>
                    <li>
                        <a href="tracking.php">Courier locator</a>

                    </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="contact.php" data-toggle="dropdown">Contact us <span class="caret"></span></a>
                         <div class="arrow-up"></div>
							<ul class="dropdown-menu arrow_up" role="menu">
                                    <li><a class="parent" href="faq.php">FAQs</a></li>
                                    <li><a class="parent" href="contact.php">Fastway depot</a></li>
                                    <li><a class="parent" href="tracking.php">Fastway courier</a></li>
                                    <li><a class="parent" href="feedback.php">Feedback</a></li>
                            </ul>
                        </li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>


			



<!-- Hide left menu --------------------------------------------->




<!-- Banner --------------------------------------------->





<div class="container paddTopBottom pagebg">


	 <!--Right side ---------->
	 		<div class="col-xs-12 col-sm-8 col-sm-push-4 col-md-9 col-md-push-3">
			<div class="row">

<!-- Breadcrumb---------->

<!-- Heading ---------->
<h1 class="articleTitle">Contact us for 24 Hours Support</h1>

	<!-- Content ---------->

		<section>
		<h4>Istanbul, Turkey</h4>
<p>Yesiltepe Mahallesi, G-2. Sk. No:7, 34025 Zeytinburnu Istanbul, Turkey<br>
<p>Tel;+90 545 330 2062, +79-150-4573-3340</p>
<p>Email:<a href="mailto:customersupport@fastwayservices.co">customersupport@fastwayservices.co</a></p>
<p><strong>Operations Supervisor:</strong>&nbsp;Michel Lavallée</p>
<p><strong>Operations Manager:</strong>&nbsp;Christophe Sourd</p>
<br>
<h4> Alaska, United States</h4>
<p>Tel;<a href="tel:+1(518)855-8181">+1(518)855-8181</a>
</p>
<p>Email;<a href="mailto:enquiries@fastwayservices.co">enquiries@fastwayservices.co</a></p>
<p><strong>Supervisor, Customer Service:</strong>&nbsp;Annie Bruyne</p>
<br>
<h4> Kyiv City, Ukraine</h4>
<p>110A Antonovycha Street , 176, kyiv City, Ukraine</p>
<p>Tel;+380637673086</p>
<p>Tel;+380637673058</p>
<p>Email;<a href="mailto:parcel@fastwayservices.co">parcel@fastwayservices.co</a></p>
<p><strong>Supervisor, Customer Service:</strong>&nbsp;Maria Boran</p>

    <div class="umb-grid">
                <div class="grid-section">
                </div>
    </div>


		</section>



			 </div>
			</div>


<!--Left menu ---------->
<div class="col-xs-12 col-sm-4 col-sm-pull-8 col-md-3 col-md-pull-9">








<nav>
<ul class="leftMenu">


<li class="leftMenuTitle">
 <h4>Contact us</h4>
</li>



        <li>

 <a href="faq.php">FAQs</a>

       </li>
        <li>

 <a href="contact.php">Fastway depot</a>

       </li>
        <li>

 <a href="About.php">Fastway courier</a>

       </li>
        <li>

 <a href="tracking.php" class="CurrentPage">Service updates</a>


       </li>

</ul>
</nav>



<script type="text/javascript">


</script>



</div>


	</div>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","143510159313672");fbq("set","agent","tmgoogletagmanager","143510159313672");fbq("track","PageView");</script>


<footer class="footerBtm">
<div class="container">
<section>
<div class="footerWrapper">


<div class="col-xs-12">
<div class="hidden-xs">

	<h4>Fastway depots</h4>


		<ul class="footerDepots">
			<li> <a href="">Adelaide</a>	</li>
			<li> <a href="">Albury</a>	</li>
			<li> <a href="">Bendigo</a>	</li>
			<li> <a href="">Brisbane</a>	</li>
			<li> <a href="">Cairns</a>	</li>
			<li> <a href="">Canberra</a>	</li>
			<li> <a href="">Capricorn Coast</a>	</li>
			<li> <a href="">Central Coast</a>	</li>
			<li> <a href="">Coffs Harbour</a>	</li>
			<li> <a href="">Geelong &amp; Ballarat</a>	</li>
			<li> <a href="">Gold Coast</a>	</li>
			<li> <a href="">Hobart</a>	</li>
			<li> <a href="">Launceston</a>	</li>
			<li> <a href="">Mackay</a>	</li>
			<li> <a href="">Melbourne</a>	</li>
			<li> <a href="">Newcastle</a>	</li>
			<li> <a href="">Northern Rivers</a>	</li>
			<li> <a href="">Orange</a>	</li>
			<li> <a href="">Perth</a>	</li>
			<li> <a href="">Port Macquarie</a>	</li>
			<li> <a href="">Sunshine Coast</a>	</li>
			<li> <a href="">Sydney</a>	</li>
			<li> <a href="">Tamworth</a>	</li>
			<li> <a href="">Toowoomba</a>	</li>
			<li> <a href="">Townsville</a>	</li>
			<li> <a href="">Wide Bay</a>	</li>
			<li> <a href="">Wollongong</a>	</li>
		</ul>
<hr>

	</div>
</div>


<div class="col-xs-12 col-md-3">

<div class="hidden-xs">
	<h4>Why Fastway</h4>
<ul>
  <li><a href="About.php">About us</a></li>
       <!-- <li><a href="/why-fastway/our-blog/">Our blog</a></li>-->
        <li><a href="customers.php">Our customers</a></li>
        <li><a href="customers.php">Our awards</a> </li>
        <li><a href="About.php">Our community</a></li>
</ul>
	</div>

	<div class="hidden-xs">
	<h4><a href="contact.php">Contact us</a></h4>
</div>


  </div>



        <div class="col-xs-12 col-md-3">

<div class="hidden-xs">
<h4>Our services</h4>
<ul>

        <li><a class="CurrentPage" href="register.php">Send your parcel</a></li>
        <li><a href="register.php">Registration</a></li>
		<li><a href="tracking.php">Receiver pays</a></li>
</ul>
</div>


</div>







  <div class="col-xs-12 col-md-3">

<div class="hidden-xs">
	<h4>Franchise</h4>
<ul>
	<li><a href="">Fastway franchise</a></li>
	<li><a href="">Courier franchise opportuniites</a></li>
	<li><a href="">Regional franchise opportunities</a></li>
</ul></div>



<h4>Apps</h4>
<ul>
<li><i class="fa fa-apple"></i><a target="_blank" href=""> Fastway App </a></li>
<li><i class="fa fa-android"></i><a target="_blank" href=""> Fastway App </a></li>
</ul>

  </div>





  <div class="col-xs-12 col-md-3">


	<h4>Terms and conditions</h4>
<ul>
	<li><a href="">Privacy policy</a></li>
	<li><a href="">Privacy collection statement</a></li>
	<li><a href="">Terms of use</a></li>
	<li><a href="">Conditions of carriage</a></li>
	<li><a href="">Authority to leave</a></li>
</ul>


<div class="hidden-xs">
	<h4>Proudly supporting</h4>
<ul>
	<li><a target="_blank" href="https://www.beyondblue.org.au/">Beyond Blue</a></li>
	<li><a target="_blank" href="http://www.daffodilday.com.au/">Cancer Council</a></li>
</ul></div>

  </div>


  </div>




 </section>
 </div>
</footer>


<!-- BACK TO TOP -->
    <span id="top-link-block">
        <a href="index.php/#top" class="well well-sm">
  			<i class="fa fa-chevron-up" aria-hidden="true"></i>
        </a>
    </span>
    <!--// BACK TO TOP -->


		 <footer class="copyrightBtm">
      <div class="container">



	<div class="col-xs-7 col-sm-9">
		<p>© Fastway Global Couriers (Worldwide)</p>
	</div>

	<div class="col-xs-5 col-sm-3">
	<div class="social-media" style="float: right;">
		<a target="_blank" href="index.php" style="padding-left: 4px; ; padding-right: 4px;" ><img alt="icon facebook" src="./contact_files/icon_facebook.png"></a>
	</div>
	</div>




 </div>
</footer>


<!-- CDF: No JS dependencies were declared //-->


<script src="./contact_files/saved_resource" type="text/javascript"></script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d4a9ded7d27204601c9b951/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</body>
</html>